{
    "name": "Governance Documents",
    "version": "19.0.1.0.0",
    "category": "Real Estate/Governance",
    "summary": "Integração entre governança e document_core sem depender de property_core",
    "author": "Franco Poleo / Manuela Silva",
    "license": "LGPL-3",
    "depends": ["governance", "governance_property", "document_core"],
    "data": [
        "views/governance_document_views.xml"
    ],
    "installable": True,
    "application": False,
    "auto_install": False
}

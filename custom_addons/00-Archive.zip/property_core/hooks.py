# -*- coding: utf-8 -*-
import logging

_logger = logging.getLogger(__name__)


def _disable_binary_tracking(env):
    """Disable mail tracking for binary fields left by old development versions."""
    env.cr.execute("""
        UPDATE ir_model_fields
           SET tracking = 0
         WHERE model IN ('property.asset', 'property.media', 'property.complex')
           AND ttype = 'binary'
           AND COALESCE(tracking, 0) <> 0
    """)



def pre_init_hook(env):
    """Remove cached views BEFORE loading XML to avoid validation errors.

    Note: In Odoo 19, pre_init_hook receives only env, not cr and registry.
    """
    try:
        _logger.info("[property_core] Starting pre_init_hook: clearing old views...")

        cr = env.cr

        # Step 1: Find parent view IDs via ir_model_data
        sql_find_parents = """
            SELECT res_id FROM ir_model_data
            WHERE module = 'property_core'
            AND name IN (
                'view_property_contract_form',
                'view_property_complex_form',
                'view_property_asset_form'
            )
            AND model = 'ir.ui.view'
        """
        cr.execute(sql_find_parents)
        parent_view_ids = [row[0] for row in cr.fetchall()]
        _logger.info(f"[property_core] Found parent view IDs: {parent_view_ids}")

        # Step 2: Find and delete child views (inherited views)
        if parent_view_ids:
            placeholders = ','.join(['%s'] * len(parent_view_ids))
            sql_delete_children = f"""
                DELETE FROM ir_ui_view
                WHERE inherit_id IN ({placeholders})
            """
            cr.execute(sql_delete_children, parent_view_ids)
            affected = cr.rowcount
            _logger.info(f"[property_core] Deleted {affected} inherited views")

        # Step 3: Delete parent views
        if parent_view_ids:
            placeholders = ','.join(['%s'] * len(parent_view_ids))
            sql_delete_parent = f"""
                DELETE FROM ir_ui_view
                WHERE id IN ({placeholders})
            """
            cr.execute(sql_delete_parent, parent_view_ids)
            affected = cr.rowcount
            _logger.info(f"[property_core] Deleted {affected} parent views")

        # Step 4: Clean up ir_model_data entries
        sql_delete_data = """
            DELETE FROM ir_model_data
            WHERE module = 'property_core'
            AND name IN (
                'view_property_contract_form',
                'view_property_complex_form',
                'view_property_asset_form'
            )
            AND model = 'ir.ui.view'
        """
        cr.execute(sql_delete_data)
        _logger.info(f"[property_core] Cleaned up ir_model_data entries")

        cr.commit()
        _logger.info("[property_core] pre_init_hook completed successfully")

    except Exception as e:
        _logger.exception("[property_core] Error in pre_init_hook: %s" % str(e))
        env.cr.rollback()
        # Don't raise, allow Odoo to continue


def post_init_hook(env):
    """Cleanup hook after initialization.

    Note: In Odoo 19, post_init_hook also receives only env.
    """
    try:
        _logger.info("[property_core] Starting post_init_hook: cleaning up media conflicts...")

        _disable_binary_tracking(env)

        # Clean up mídias with both image_1920 and file_data populated
        PropertyMedia = env['property.media']
        PropertyMedia.action_cleanup_binary_conflicts()

        _logger.info("[property_core] post_init_hook completed successfully")

    except Exception as e:
        _logger.exception("[property_core] Error in post_init_hook: %s" % str(e))
        env.cr.rollback()
        # Don't raise, allow Odoo to continue
# Índice da Documentação Consolidada

Este pacote preserva a documentação anterior e adiciona dois arquivos padronizados por módulo:

- `docs/DOCUMENTACAO_TECNICA.md`
- `docs/MANUAL_USUARIO.md`

## Módulos documentados

- `account_latam_provisional_post` — Documento Fiscal Provisório LATAM/Brasil
- `common_base` — Common Base
- `document_core` — Document Core
- `document_dossier` — Document Dossier - Aggregator
- `document_dossier_governance` — Document Dossier - Governance Integration
- `document_dossier_property` — Document Dossier - Property Integration
- `document_s3_storage` — Document S3 Storage
- `governance` — Governance & Audit
- `governance_documents` — Governance Documents
- `governance_property` — Governance Property
- `l10n_br_partner_cep_identity` — Brasil - Contatos: CEP e Documentos
- `payment_pix` — Payment Provider: PIX (BACEN)
- `property_contract_amendment_enterprise` — Contratos e Aditivos Imobiliários Empresarial
- `property_contract_history` — Histórico de Contratos com OCR
- `property_contract_ocr_template` — Property Contract OCR Templates
- `property_core` — Property Core
- `property_document_portal` — Property Document Portal
- `property_payment_proof` — Conciliação Inteligente de Comprovantes de Aluguel
- `property_valuation_engine` — Property Valuation Engine

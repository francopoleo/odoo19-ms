
from odoo import api, fields, models, _
from datetime import date


class PropertyOwner(models.Model):
    _name = "property.owner"
    _description = "Proprietário de Imóvel"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "name"
    _rec_name = "name"

    name = fields.Char("Nome", required=True, tracking=True, help="Nome principal do cadastro exibido no sistema.")
    stakeholder_profile_id = fields.Many2one("property.stakeholder.profile", string="Perfil Central", ondelete="set null")

    partner_id = fields.Many2one("res.partner", string="Contato / Acesso Portal", help="Contato mestre do proprietário. Recomendado para uma gestão enterprise unificada.")
    cpf_cnpj = fields.Char("CPF / CNPJ", tracking=True, help="Documento fiscal do proprietário para identificação e obrigações contratuais/fiscais.")
    active = fields.Boolean(default=True)
    email = fields.Char("E-mail", tracking=True, help="E-mail principal de contato.")
    phone = fields.Char("Telefone", tracking=True, help="Telefone principal para contato.")
    mobile = fields.Char("Celular / WhatsApp", tracking=True, help="Celular ou WhatsApp para contato rápido.")
    street = fields.Char("Endereço", help="Endereço principal do proprietário.")
    city = fields.Char("Cidade", help="Cidade principal do proprietário.")
    state_name = fields.Char("Estado", help="Estado principal do proprietário.")
    is_company = fields.Boolean("Pessoa Jurídica", help="Marque quando o proprietário for empresa, holding ou entidade jurídica.")

    bank_name = fields.Char("Banco", help="Banco usado para repasses e pagamentos ao proprietário.")
    bank_agency = fields.Char("Agência", help="Agência bancária do proprietário.")
    bank_account = fields.Char("Conta", help="Conta bancária do proprietário para repasses.")
    pix_key = fields.Char("Chave PIX", tracking=True, help="Chave PIX para repasses rápidos ao proprietário.")

    asset_ids = fields.One2many("property.asset", "owner_id", string="Imóveis")
    repasse_ids = fields.One2many("property.owner.repasse", "owner_id", string="Repasses")
    repasse_count = fields.Integer("Qtd. Repasses", compute="_compute_repasse_count")

    currency_id = fields.Many2one("res.currency", default=lambda self: self.env.company.currency_id)
    asset_count = fields.Integer("Qtd. Imóveis", compute="_compute_stats", store=True)
    active_contract_count = fields.Integer("Contratos Ativos", compute="_compute_stats", store=True)
    total_monthly_income = fields.Monetary("Receita Mensal Bruta", currency_field="currency_id", compute="_compute_stats", store=True)
    total_annual_costs = fields.Monetary("Custos Anuais", currency_field="currency_id", compute="_compute_stats", store=True)
    net_monthly = fields.Monetary("Resultado Mensal Líquido Estimado", currency_field="currency_id", compute="_compute_stats", store=True)

    notes = fields.Text("Observações", help="Campo livre para observações internas, contexto operacional e orientações da equipe.")
    company_id = fields.Many2one("res.company", default=lambda self: self.env.company, index=True, help="Empresa responsável por este registro em ambientes multiempresa.")

    @api.depends("asset_ids", "asset_ids.total_annual_costs", "asset_ids.contract_ids", "asset_ids.contract_ids.status", "asset_ids.contract_ids.monthly_rent")
    def _compute_stats(self):
        for owner in self:
            assets = owner.asset_ids
            owner.asset_count = len(assets)
            active_contracts = self.env["property.contract"].search([("asset_id", "in", assets.ids), ("status", "=", "active")])
            owner.active_contract_count = len(active_contracts)
            owner.total_monthly_income = sum(active_contracts.mapped("monthly_rent"))
            annual_costs = sum(assets.mapped("total_annual_costs"))
            owner.total_annual_costs = annual_costs
            owner.net_monthly = owner.total_monthly_income - (annual_costs / 12)

    def _compute_repasse_count(self):
        for owner in self:
            owner.repasse_count = len(owner.repasse_ids)

    def _owner_partner_category(self):
        return self.env.ref("property_core.res_partner_category_owner", raise_if_not_found=False)

    def _prepare_partner_vals(self):
        self.ensure_one()
        vals = {
            "name": self.name,
            "email": self.email,
            "phone": self.phone or self.mobile,
            "mobile": self.mobile,
            "street": self.street,
            "city": self.city,
            "company_id": self.company_id.id,
            "company_type": "company" if self.is_company else "person",
        }
        return {k: v for k, v in vals.items() if v not in (False, None, "")}

    def _ensure_profile(self):
        stype = self.env.ref("property_core.stakeholder_type_owner", raise_if_not_found=False)
        for rec in self:
            if rec.partner_id and stype and not rec.stakeholder_profile_id:
                profile = self.env["property.stakeholder.profile"].search([("partner_id", "=", rec.partner_id.id), ("stakeholder_type_id", "=", stype.id)], limit=1)
                if not profile:
                    profile = self.env["property.stakeholder.profile"].create({"partner_id": rec.partner_id.id, "stakeholder_type_id": stype.id, "company_id": rec.env.company.id})
                rec.stakeholder_profile_id = profile.id

    def _sync_partner(self):
        cat = self._owner_partner_category()
        for rec in self:
            if rec.partner_id:
                rec.partner_id.write(rec._prepare_partner_vals())
                if cat and cat not in rec.partner_id.category_id:
                    rec.partner_id.category_id = [(4, cat.id)]
            else:
                vals = rec._prepare_partner_vals()
                if cat:
                    vals.setdefault("category_id", [(6, 0, [cat.id])])
                rec.partner_id = self.env["res.partner"].create(vals)

    @api.onchange("partner_id")
    def _onchange_partner_id(self):
        for rec in self:
            if rec.partner_id:
                rec.name = rec.partner_id.name or rec.name
                rec.email = rec.partner_id.email or rec.email
                rec.phone = rec.partner_id.phone or rec.phone
                rec.mobile = rec.partner_id.mobile or rec.mobile
                rec.street = rec.partner_id.street or rec.street
                rec.city = rec.partner_id.city or rec.city
                rec.is_company = rec.partner_id.company_type == "company"
                if not rec.cpf_cnpj:
                    rec.cpf_cnpj = rec.partner_id.vat

    @api.model_create_multi
    def create(self, vals_list):
        recs = super().create(vals_list)
        recs._sync_partner()
        recs._ensure_profile()
        return recs

    def write(self, vals):
        res = super().write(vals)
        tracked = {"name", "email", "phone", "mobile", "street", "city", "partner_id", "is_company", "company_id"}
        if tracked.intersection(vals.keys()):
            self._sync_partner()
            self._ensure_profile()
        return res

    def action_view_assets(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": "Imóveis",
            "res_model": "property.asset",
            "view_mode": "list,form",
            "domain": [("owner_id", "=", self.id)],
            "context": {"default_owner_id": self.id},
        }

    def action_generate_statement(self):
        self.ensure_one()
        return self.env.ref("property_core.action_report_owner_statement").report_action(self)

    def action_view_repasses(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": "Repasses",
            "res_model": "property.owner.repasse",
            "view_mode": "list,form",
            "domain": [("owner_id", "=", self.id)],
            "context": {"default_owner_id": self.id},
        }

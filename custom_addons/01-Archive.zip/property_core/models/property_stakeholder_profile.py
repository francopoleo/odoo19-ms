from odoo import api, fields, models, _
from odoo.exceptions import ValidationError, UserError


class PropertyStakeholderProfile(models.Model):
    _name = "property.stakeholder.profile"
    _description = "Perfil Imobiliário do Contato"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "partner_id, stakeholder_type_id"
    _rec_name = "display_name"

    display_name = fields.Char(compute="_compute_display_name", store=True)
    active = fields.Boolean(default=True)
    partner_id = fields.Many2one("res.partner", string="Contato Mestre", required=True, ondelete="restrict", tracking=True, help="Contato mestre do Odoo que representa esta pessoa ou empresa.")
    stakeholder_type_id = fields.Many2one("property.stakeholder.type", string="Perfil / Papel Imobiliário", required=True, ondelete="restrict", tracking=True, help="Define o papel funcional deste contato no contexto imobiliário, como proprietário, locatário, corretor, comprador ou investidor.")
    role_status = fields.Selection([
        ("draft", "Rascunho"),
        ("active", "Ativo"),
        ("inactive", "Inativo"),
        ("blocked", "Bloqueado"),
    ], string="Status", default="active", required=True, tracking=True)
    company_id = fields.Many2one("res.company", default=lambda self: self.env.company, required=True, index=True)
    start_date = fields.Date("Início")
    end_date = fields.Date("Fim")
    user_id = fields.Many2one("res.users", string="Usuário Relacionado", help="Usuário interno associado a este perfil, quando houver. Útil para corretores, responsáveis comerciais e operação interna.")
    brokerage_profile_id = fields.Many2one("property.stakeholder.profile", string="Imobiliária Vinculada", domain="[('stakeholder_type_id.code', '=', 'brokerage')]", help="Use este campo quando o perfil estiver ligado a uma imobiliária já cadastrada como perfil imobiliário do tipo Imobiliária.")
    registration_number = fields.Char("Registro Profissional / Empresarial", help="Número de CRECI, registro empresarial ou outro identificador profissional relacionado ao papel deste perfil.")
    notes = fields.Text("Orientações e Observações", help="Use este campo para registrar instruções operacionais, contexto do relacionamento e observações internas sobre este perfil.")

    @api.depends("partner_id", "stakeholder_type_id")
    def _compute_display_name(self):
        for rec in self:
            parts = [rec.partner_id.name or ""]
            if rec.stakeholder_type_id.name:
                parts.append(rec.stakeholder_type_id.name)
            rec.display_name = " • ".join([p for p in parts if p])

    @api.constrains("partner_id", "stakeholder_type_id")
    def _check_unique_partner_type(self):
        for rec in self:
            duplicate = self.search([
                ("id", "!=", rec.id),
                ("partner_id", "=", rec.partner_id.id),
                ("stakeholder_type_id", "=", rec.stakeholder_type_id.id),
            ], limit=1)
            if duplicate:
                raise ValidationError("O contato já possui este tipo de perfil imobiliário.")

    @api.constrains("end_date", "start_date")
    def _check_dates(self):
        for rec in self:
            if rec.start_date and rec.end_date and rec.end_date < rec.start_date:
                raise ValidationError(_("A data final não pode ser menor que a data inicial."))

    def _sync_partner_tag(self):
        for rec in self:
            tag = rec.stakeholder_type_id.default_partner_tag_id
            if rec.partner_id and tag and tag not in rec.partner_id.category_id:
                rec.partner_id.category_id = [(4, tag.id)]

    def _operational_model_map(self):
        return {
            "owner": "property.owner",
            "tenant": "property.tenant",
            "buyer": "property.buyer",
            "seller": "property.seller",
            "broker": "property.broker",
            "brokerage": "property.brokerage",
            "investor": "property.investor",
            "developer": "property.developer",
        }

    def _get_operational_model_name(self):
        self.ensure_one()
        code = self.stakeholder_type_id.code or ""
        return self._operational_model_map().get(code)

    def _prepare_operational_vals(self):
        self.ensure_one()
        model_name = self._get_operational_model_name()
        if not model_name:
            return {}
        model = self.env[model_name]
        vals = {}
        if "partner_id" in model._fields:
            vals["partner_id"] = self.partner_id.id
        if "stakeholder_profile_id" in model._fields:
            vals["stakeholder_profile_id"] = self.id
        if "company_id" in model._fields:
            vals["company_id"] = self.company_id.id
        if "user_id" in model._fields and self.user_id:
            vals["user_id"] = self.user_id.id
        if "name" in model._fields and not model._fields["name"].related:
            vals["name"] = self.partner_id.name
        if "email" in model._fields and not model._fields["email"].related and self.partner_id.email:
            vals["email"] = self.partner_id.email
        if "phone" in model._fields and not model._fields["phone"].related and self.partner_id.phone:
            vals["phone"] = self.partner_id.phone
        if "mobile" in model._fields and not model._fields["mobile"].related and self.partner_id.mobile:
            vals["mobile"] = self.partner_id.mobile
        if "active" in model._fields:
            vals["active"] = self.role_status not in ("inactive", "blocked")
        if "registration_number" in self._fields:
            if "creci" in model._fields and self.registration_number:
                vals["creci"] = self.registration_number
        if "brokerage_id" in model._fields and self.brokerage_profile_id:
            brokerage = self.env["property.brokerage"].search([(
                "stakeholder_profile_id", "=", self.brokerage_profile_id.id
            )], limit=1)
            if brokerage:
                vals["brokerage_id"] = brokerage.id
        return vals

    def _find_operational_record(self):
        self.ensure_one()
        model_name = self._get_operational_model_name()
        if not model_name:
            return self.env["ir.model"]
        model = self.env[model_name]
        domain = []
        if "stakeholder_profile_id" in model._fields:
            domain = [("stakeholder_profile_id", "=", self.id)]
            rec = model.search(domain, limit=1)
            if rec:
                return rec
        if "partner_id" in model._fields:
            code = self.stakeholder_type_id.code or ""
            rec = model.search([("partner_id", "=", self.partner_id.id)], limit=1)
            # avoid linking unrelated records when same partner has multiple roles in other models
            if code in {"owner", "tenant", "buyer", "seller", "broker", "brokerage", "investor", "developer"}:
                return rec
        return model.browse()

    def _ensure_operational_record(self):
        for rec in self:
            model_name = rec._get_operational_model_name()
            if not model_name or not rec.partner_id:
                continue
            model = rec.env[model_name]
            operational = rec._find_operational_record()
            vals = rec._prepare_operational_vals()
            if operational:
                operational.write(vals)
            else:
                model.create(vals)

    @api.model_create_multi
    def create(self, vals_list):
        recs = super().create(vals_list)
        recs._sync_partner_tag()
        recs._ensure_operational_record()
        return recs

    def write(self, vals):
        res = super().write(vals)
        if {"stakeholder_type_id", "partner_id", "user_id", "role_status", "company_id", "registration_number", "brokerage_profile_id"} & set(vals.keys()):
            self._sync_partner_tag()
            self._ensure_operational_record()
        return res

    def action_open_partner(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "res_model": "res.partner",
            "view_mode": "form",
            "res_id": self.partner_id.id,
        }

    def action_open_operational_record(self):
        self.ensure_one()
        model_name = self._get_operational_model_name()
        if not model_name:
            raise UserError(_("Este perfil não possui um cadastro operacional específico. Use o contato mestre e o próprio perfil imobiliário."))
        operational = self._find_operational_record()
        if not operational:
            self._ensure_operational_record()
            operational = self._find_operational_record()
        if not operational:
            raise UserError(_("Não foi possível localizar nem criar o cadastro operacional deste perfil."))
        return {
            "type": "ir.actions.act_window",
            "res_model": model_name,
            "view_mode": "form",
            "res_id": operational.id,
            "target": "current",
        }

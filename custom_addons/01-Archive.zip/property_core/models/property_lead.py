from odoo import api, fields, models, _


class PropertyLead(models.Model):
    _name = "property.lead"
    _description = "Interesse em Imóvel"
    _inherit = ["mail.thread"]
    _order = "create_date desc"
    _rec_name = "name"

    # ==================== Contato ====================
    name = fields.Char("Nome", required=True, tracking=True, help="Nome principal do cadastro exibido no sistema.")
    email = fields.Char("E-mail", required=True, tracking=True)
    phone = fields.Char("Telefone", tracking=True, help="Telefone principal para contato.")
    stakeholder_profile_id = fields.Many2one("property.stakeholder.profile", string="Perfil Central", ondelete="set null")

    partner_id = fields.Many2one("res.partner", string="Contato Relacionado", tracking=True, help="Contato mestre criado ou vinculado automaticamente para este lead.")

    # ==================== Imóvel ====================
    asset_id = fields.Many2one(
        "property.asset", string="Imóvel",
        required=True, ondelete="cascade", tracking=True
    )
    interest_type = fields.Selection([
        ("rent", "Locação"),
        ("buy", "Compra"),
        ("both", "Locação ou Compra"),
    ], string="Interesse", default="rent", tracking=True)

    message = fields.Text("Mensagem", help="Mensagem livre enviada pelo interessado sobre o imóvel.")
    source_channel = fields.Selection([
        ("website_public", "Site Público"),
        ("website_portal", "Site com Login"),
        ("website_broker", "Área Restrita de Corretor"),
        ("internal", "Interno"),
    ], string="Origem", default="website_public", tracking=True)
    submitter_user_id = fields.Many2one("res.users", string="Usuário Solicitante", tracking=True)
    access_profile = fields.Char("Perfil de Acesso", tracking=True, help="Perfil de acesso do usuário no momento do envio: público, portal, corretor etc.")

    # ==================== Corretor ====================
    broker_id = fields.Many2one(
        "property.broker", string="Corretor Responsável",
        tracking=True
    )

    # ==================== Status ====================
    status = fields.Selection([
        ("new", "Novo"),
        ("contacted", "Contatado"),
        ("qualified", "Qualificado"),
        ("lost", "Perdido"),
    ], default="new", tracking=True, required=True)

    company_id = fields.Many2one(
        "res.company", default=lambda self: self.env.company, index=True
    )


    def _lead_partner_category(self):
        return self.env.ref("property_core.res_partner_category_property_prospect", raise_if_not_found=False)

    def _ensure_profile(self):
        stype = self.env.ref("property_core.stakeholder_type_broker", raise_if_not_found=False)
        for rec in self:
            if rec.partner_id and stype and not rec.stakeholder_profile_id:
                profile = self.env["property.stakeholder.profile"].search([("partner_id", "=", rec.partner_id.id), ("stakeholder_type_id", "=", stype.id)], limit=1)
                if not profile:
                    profile = self.env["property.stakeholder.profile"].create({"partner_id": rec.partner_id.id, "stakeholder_type_id": stype.id, "company_id": rec.env.company.id, "user_id": rec.user_id.id or False})
                rec.stakeholder_profile_id = profile.id

    def _sync_partner(self):
        cat = self._lead_partner_category()
        for rec in self:
            vals = {"name": rec.name, "email": rec.email, "phone": rec.phone}
            vals = {k: v for k, v in vals.items() if v}
            partner = rec.partner_id
            if not partner and rec.email:
                partner = self.env["res.partner"].search([("email", "=", rec.email)], limit=1)
            if partner:
                partner.write(vals)
                if cat and cat not in partner.category_id:
                    partner.category_id = [(4, cat.id)]
                rec.partner_id = partner
            else:
                if cat:
                    vals["category_id"] = [(6, 0, [cat.id])]
                rec.partner_id = self.env["res.partner"].create(vals)

    # ==================== Actions ====================

    def action_set_contacted(self):
        self.ensure_one()
        self.status = "contacted"
        self.message_post(body=_("Lead marcado como Contatado."))

    def action_set_qualified(self):
        self.ensure_one()
        self.status = "qualified"
        self.message_post(body=_("Lead qualificado."))

    def action_set_lost(self):
        self.ensure_one()
        self.status = "lost"
        self.message_post(body=_("Lead perdido."))
    @api.model_create_multi
    def create(self, vals_list):
        recs = super().create(vals_list)
        recs._sync_partner()
        recs._ensure_profile()
        return recs

    def write(self, vals):
        res = super().write(vals)
        if {"name", "email", "phone", "partner_id"}.intersection(vals.keys()):
            self._sync_partner()
            self._ensure_profile()
        return res

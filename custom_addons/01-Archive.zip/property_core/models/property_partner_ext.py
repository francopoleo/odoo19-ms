from odoo import api, fields, models
from odoo.addons.common_base.models.partner_resolution import MATCH_SOURCES  # noqa: F401 — re-export


class ResPartner(models.Model):
    _inherit = "res.partner"

    mobile = fields.Char(
        string="Celular",
        help="Número de celular principal do contato."
    )

    property_stakeholder_profile_ids = fields.One2many(
        "property.stakeholder.profile",
        "partner_id",
        string="Perfis Imobiliários",
        help="Perfis imobiliários vinculados a este contato mestre. Use esta seção para atribuir papéis como proprietário, locatário, corretor ou investidor sem criar um novo contato.",
    )
    has_property_stakeholder_profile = fields.Boolean(
        string="Possui Perfil Imobiliário",
        compute="_compute_has_property_stakeholder_profile",
        compute_sudo=True,
    )
    property_stakeholder_profile_count = fields.Integer(
        compute="_compute_property_stakeholder_display_counts",
        compute_sudo=True,
    )
    property_owner_count = fields.Integer(
        compute="_compute_property_stakeholder_display_counts",
        compute_sudo=True,
    )
    property_broker_count = fields.Integer(
        compute="_compute_property_stakeholder_display_counts",
        compute_sudo=True,
    )
    property_tenant_count = fields.Integer(
        compute="_compute_property_stakeholder_display_counts",
        compute_sudo=True,
    )
    property_buyer_count = fields.Integer(
        compute="_compute_property_stakeholder_display_counts",
        compute_sudo=True,
    )
    property_seller_count = fields.Integer(
        compute="_compute_property_stakeholder_display_counts",
        compute_sudo=True,
    )
    property_investor_count = fields.Integer(
        compute="_compute_property_stakeholder_display_counts",
        compute_sudo=True,
    )
    property_brokerage_count = fields.Integer(
        compute="_compute_property_stakeholder_display_counts",
        compute_sudo=True,
    )
    property_developer_count = fields.Integer(
        compute="_compute_property_stakeholder_display_counts",
        compute_sudo=True,
    )
    property_lead_count = fields.Integer(
        compute="_compute_property_stakeholder_display_counts",
        compute_sudo=True,
    )

    @api.depends("property_stakeholder_profile_ids")
    def _compute_has_property_stakeholder_profile(self):
        for rec in self:
            rec.has_property_stakeholder_profile = bool(rec.property_stakeholder_profile_ids)

    def _compute_property_stakeholder_display_counts(self):
        Owner = self.env["property.owner"].sudo()
        Broker = self.env["property.broker"].sudo()
        Tenant = self.env["property.tenant"].sudo()
        Buyer = self.env["property.buyer"].sudo()
        Seller = self.env["property.seller"].sudo()
        Investor = self.env["property.investor"].sudo()
        Brokerage = self.env["property.brokerage"].sudo()
        Developer = self.env["property.developer"].sudo()
        Lead = self.env["property.lead"].sudo()

        for rec in self.sudo():
            rec.property_stakeholder_profile_count = len(rec.property_stakeholder_profile_ids)
            rec.property_owner_count = Owner.search_count([("partner_id", "=", rec.id)])
            rec.property_broker_count = Broker.search_count([("partner_id", "=", rec.id)])
            rec.property_tenant_count = Tenant.search_count([("partner_id", "=", rec.id)])
            rec.property_buyer_count = Buyer.search_count([("partner_id", "=", rec.id)])
            rec.property_seller_count = Seller.search_count([("partner_id", "=", rec.id)])
            rec.property_investor_count = Investor.search_count([("partner_id", "=", rec.id)])
            rec.property_brokerage_count = Brokerage.search_count([("partner_id", "=", rec.id)])
            rec.property_developer_count = Developer.search_count([("partner_id", "=", rec.id)])
            rec.property_lead_count = Lead.search_count([("partner_id", "=", rec.id)])

    def _open_partner_related(self, model_name, title):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": title,
            "res_model": model_name,
            "view_mode": "list,form",
            "domain": [("partner_id", "=", self.id)],
            "context": {"default_partner_id": self.id},
        }

    def action_view_property_stakeholder_profiles(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": "Perfis Imobiliários",
            "res_model": "property.stakeholder.profile",
            "view_mode": "list,form",
            "domain": [("partner_id", "=", self.id)],
            "context": {"default_partner_id": self.id},
        }


    def action_new_property_stakeholder_profile(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": "Novo Perfil Imobiliário",
            "res_model": "property.stakeholder.profile",
            "view_mode": "form",
            "target": "current",
            "context": {
                "default_partner_id": self.id,
                "default_company_id": self.env.company.id,
            },
        }

    def action_view_property_owners(self):
        return self._open_partner_related("property.owner", "Proprietários")

    def action_view_property_brokers(self):
        return self._open_partner_related("property.broker", "Corretores")

    def action_view_property_tenants(self):
        return self._open_partner_related("property.tenant", "Locatários")

    def action_view_property_buyers(self):
        return self._open_partner_related("property.buyer", "Compradores")

    def action_view_property_sellers(self):
        return self._open_partner_related("property.seller", "Vendedores")

    def action_view_property_investors(self):
        return self._open_partner_related("property.investor", "Investidores")

    def action_view_property_brokerages(self):
        return self._open_partner_related("property.brokerage", "Imobiliárias")

    def action_view_property_developers(self):
        return self._open_partner_related("property.developer", "Incorporadoras")

    def action_view_property_leads(self):
        return self._open_partner_related("property.lead", "Leads")

    @api.model
    def _resolve_contact_extended(self, email=None, phone=None):
        """Resolução imobiliária: locatário → proprietário → lead."""
        if email:
            # Locatário — email é related de partner_id.email
            tenant = self.env['property.tenant'].sudo().search(
                [('partner_id.email', '=ilike', email)], limit=1
            )
            if tenant and tenant.partner_id:
                return (tenant.partner_id, 'tenant_email', 95)

            # Proprietário — tem campo email direto E partner_id opcional
            owner = self.env['property.owner'].sudo().search(
                ['|',
                 ('partner_id.email', '=ilike', email),
                 ('email', '=ilike', email)],
                limit=1,
            )
            if owner and owner.partner_id:
                return (owner.partner_id, 'owner_email', 95)

            # Lead — email direto, partner_id opcional
            lead = self.env['property.lead'].sudo().search(
                [('email', '=ilike', email), ('partner_id', '!=', False)], limit=1
            )
            if lead and lead.partner_id:
                return (lead.partner_id, 'lead_email', 85)

        return super()._resolve_contact_extended(email=email, phone=phone)

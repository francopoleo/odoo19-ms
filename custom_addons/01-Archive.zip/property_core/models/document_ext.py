from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class DocumentPropertyExt(models.Model):
    _inherit = "document.document"

    complex_id = fields.Many2one("property.complex", string="Complexo", ondelete="cascade", tracking=True)
    asset_id = fields.Many2one("property.asset", string="Imóvel", ondelete="cascade", tracking=True)
    contract_id = fields.Many2one("property.contract", string="Contrato", ondelete="set null", tracking=True)
    owner_id = fields.Many2one("property.owner", string="Proprietário", ondelete="set null", tracking=True)
    broker_id = fields.Many2one("property.broker", string="Corretor Responsável", ondelete="set null", tracking=True)
    authorized_broker_ids = fields.Many2many(
        "property.broker",
        "document_broker_rel",
        "document_id",
        "broker_id",
        string="Corretores Autorizados",
    )
    media_ids = fields.One2many("property.media", "document_id", string="Mídias de Apoio")
    media_count = fields.Integer("Qtd. Mídias", compute="_compute_media_count")

    @api.depends("media_ids")
    def _compute_media_count(self):
        for doc in self:
            doc.media_count = len(doc.media_ids)

    def _get_broker_for_user(self, user=None):
        user = user or self.env.user
        if not user or not user.exists() or user._is_public():
            return self.env["property.broker"]
        return self.env["property.broker"].sudo().search([("user_id", "=", user.id)], limit=1)

    def can_user_view_document(self, user=None, broker=None):
        self.ensure_one()
        user = user or self.env.user
        broker = broker or self._get_broker_for_user(user)

        if user.has_group("property_core.group_property_manager"):
            return True
        if self.access_level == "public":
            return True
        if self.access_level == "portal":
            return not user._is_public()
        if self.access_level == "authorized_brokers":
            return bool(broker and broker in self.authorized_broker_ids)
        if self.access_level == "internal":
            return bool(user and not user._is_public() and user.has_group("base.group_user"))
        if self.access_level in ("legal", "finance"):
            return bool(user and not user._is_public() and user.has_group("property_core.group_property_manager"))
        if self.access_level == "governance":
            return bool(user and not user._is_public() and user.has_group("governance.group_governance_user"))
        return False

    @api.depends("access_level", "website_published", "website_visibility", "authorized_broker_ids", "allowed_group_ids")
    def _compute_access_summary(self):
        access_map = dict(self._fields["access_level"].selection)
        website_map = dict(self._fields["website_visibility"].selection)
        for rec in self:
            parts = [access_map.get(rec.access_level, "")]
            if rec.website_published:
                parts.append("Site: %s" % website_map.get(rec.website_visibility, ""))
            if rec.authorized_broker_ids:
                parts.append("Corretores: %s" % len(rec.authorized_broker_ids))
            if rec.allowed_group_ids:
                parts.append("Grupos: %s" % len(rec.allowed_group_ids))
            rec.access_summary = " • ".join([p for p in parts if p])

    @api.constrains("asset_id", "contract_id", "complex_id")
    def _check_property_link(self):
        for doc in self:
            if any([doc.asset_id, doc.contract_id, doc.complex_id, getattr(doc, 'case_id', False), doc.owner_id, doc.broker_id]):
                continue
            # Permite documentos genéricos quando fora do contexto imobiliário.
            continue

from odoo import api, fields, models


class PropertyTenant(models.Model):
    _name = "property.tenant"
    _description = "Locatário"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _rec_name = "name"

    partner_id = fields.Many2one(
        "res.partner",
        string="Contato Mestre",
        required=True,
        ondelete="restrict",
        tracking=True,
    )
    stakeholder_profile_id = fields.Many2one(
        "property.stakeholder.profile",
        string="Perfil Central",
        ondelete="set null",
    )
    active = fields.Boolean(default=True)

    name = fields.Char(
        string="Nome",
        related="partner_id.name",
        store=True,
        readonly=False,
        tracking=True,
    )
    email = fields.Char(
        string="E-mail",
        related="partner_id.email",
        store=True,
        readonly=False,
    )
    phone = fields.Char(
        string="Telefone",
        related="partner_id.phone",
        store=True,
        readonly=False,
    )
    mobile = fields.Char(
        string="Celular",
        related="partner_id.mobile",
        store=True,
        readonly=False,
    )

    notes = fields.Text("Observações")
    company_id = fields.Many2one(
        "res.company", default=lambda self: self.env.company, index=True
    )
    contract_ids = fields.One2many("property.contract", "tenant_id", string="Contratos")
    contract_count = fields.Integer(compute="_compute_contract_count")

    @api.depends("contract_ids")
    def _compute_contract_count(self):
        for rec in self:
            rec.contract_count = len(rec.contract_ids)

    @api.model_create_multi
    def create(self, vals_list):
        recs = super().create(vals_list)
        recs._ensure_profile()
        return recs

    def write(self, vals):
        res = super().write(vals)
        if "partner_id" in vals:
            self._ensure_profile()
        return res

    def _ensure_profile(self):
        stype = self.env.ref("property_core.stakeholder_type_tenant", raise_if_not_found=False)
        for rec in self:
            if rec.partner_id and stype and not rec.stakeholder_profile_id:
                profile = self.env["property.stakeholder.profile"].search(
                    [
                        ("partner_id", "=", rec.partner_id.id),
                        ("stakeholder_type_id", "=", stype.id),
                    ],
                    limit=1,
                )
                if not profile:
                    profile = self.env["property.stakeholder.profile"].create(
                        {
                            "partner_id": rec.partner_id.id,
                            "stakeholder_type_id": stype.id,
                            "company_id": rec.env.company.id,
                        }
                    )
                rec.stakeholder_profile_id = profile.id

    def action_view_contracts(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": "Contratos",
            "res_model": "property.contract",
            "view_mode": "list,form",
            "domain": [("tenant_id", "=", self.id)],
            "context": {
                "default_tenant_id": self.id,
                "default_partner_id": self.partner_id.id,
            },
        }
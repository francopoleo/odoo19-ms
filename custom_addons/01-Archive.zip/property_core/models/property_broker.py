
from odoo import fields, models, api


class PropertyBroker(models.Model):
    _name = "property.broker"
    _description = "Corretor de Imóveis"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "name"
    _rec_name = "name"

    name = fields.Char("Nome", required=True, tracking=True, help="Nome principal do cadastro exibido no sistema.")
    stakeholder_profile_id = fields.Many2one("property.stakeholder.profile", string="Perfil Central", ondelete="set null")

    partner_id = fields.Many2one("res.partner", string="Contato", help="Contato mestre do corretor no Odoo.")
    stakeholder_profile_id = fields.Many2one("property.stakeholder.profile", string="Perfil Central", ondelete="set null")
    user_id = fields.Many2one("res.users", string="Usuário Relacionado", tracking=True, help="Usuário interno ou portal usado para restringir a visualização de imóveis exclusivos.")
    creci = fields.Char("CRECI", tracking=True, help="Número de registro no CRECI")
    active = fields.Boolean(default=True)
    email = fields.Char("E-mail", tracking=True, help="E-mail principal de contato.")
    phone = fields.Char("Telefone / WhatsApp", tracking=True, help="Telefone principal ou WhatsApp do corretor.")
    mobile = fields.Char("Celular", help="Celular complementar do contato.")
    company_name = fields.Char("Imobiliária / Empresa", help="Nome da empresa ou imobiliária à qual o corretor está vinculado.")
    brokerage_id = fields.Many2one("property.brokerage", string="Imobiliária Vinculada", tracking=True, help="Imobiliária à qual este corretor está vinculado.")
    is_company = fields.Boolean("Pessoa Jurídica", help="Marque quando o cadastro representar uma pessoa jurídica ou empresa corretora.")
    commission_rate = fields.Float("Comissão Padrão (%)", digits=(5, 2), default=6.0, tracking=True, help="Percentual padrão de comissão usado como referência nas operações do corretor.")

    acquisition_count = fields.Integer("Aquisições", compute="_compute_stats")
    lead_count = fields.Integer("Leads", compute="_compute_stats")
    commission_count = fields.Integer("Comissões", compute="_compute_stats")
    assignment_count = fields.Integer("Mandatos", compute="_compute_stats")
    total_commission_paid = fields.Monetary("Total Pago em Comissões", compute="_compute_stats", currency_field="currency_id")
    currency_id = fields.Many2one("res.currency", default=lambda self: self.env.company.currency_id)
    notes = fields.Text("Observações", help="Campo livre para observações internas, contexto operacional e orientações da equipe.")
    company_id = fields.Many2one("res.company", default=lambda self: self.env.company, index=True, help="Empresa responsável por este registro em ambientes multiempresa.")

    def _broker_partner_category(self):
        return self.env.ref("property_core.res_partner_category_broker", raise_if_not_found=False)

    def _prepare_partner_vals(self):
        self.ensure_one()
        vals = {
            "name": self.name,
            "email": self.email,
            "phone": self.phone or self.mobile,
            "mobile": self.mobile,
            "company_type": "company" if self.is_company else "person",
            "company_name": self.company_name,
            "company_id": self.company_id.id,
        }
        if self.creci:
            vals["comment"] = "CRECI: %s" % self.creci
        return {k: v for k, v in vals.items() if v not in (False, None, "")}

    def _ensure_profile(self):
        stype = self.env.ref("property_core.stakeholder_type_broker", raise_if_not_found=False)
        for rec in self:
            if rec.partner_id and stype and not rec.stakeholder_profile_id:
                profile = self.env["property.stakeholder.profile"].search([("partner_id", "=", rec.partner_id.id), ("stakeholder_type_id", "=", stype.id)], limit=1)
                if not profile:
                    profile = self.env["property.stakeholder.profile"].create({"partner_id": rec.partner_id.id, "stakeholder_type_id": stype.id, "company_id": rec.env.company.id, "user_id": rec.user_id.id or False})
                rec.stakeholder_profile_id = profile.id

    def _sync_partner(self):
        cat = self._broker_partner_category()
        for rec in self:
            if rec.partner_id:
                rec.partner_id.write(rec._prepare_partner_vals())
                if cat and cat not in rec.partner_id.category_id:
                    rec.partner_id.category_id = [(4, cat.id)]
            else:
                vals = rec._prepare_partner_vals()
                if cat:
                    vals.setdefault("category_id", [(6, 0, [cat.id])])
                rec.partner_id = self.env["res.partner"].create(vals)
            if rec.user_id and rec.partner_id and rec.user_id.partner_id != rec.partner_id:
                rec.user_id.partner_id = rec.partner_id

    @api.onchange("partner_id")
    def _onchange_partner_id(self):
        for rec in self:
            if rec.partner_id:
                rec.name = rec.partner_id.name or rec.name
                rec.email = rec.partner_id.email or rec.email
                rec.phone = rec.partner_id.phone or rec.phone
                rec.mobile = rec.partner_id.mobile or rec.mobile
                if not rec.company_name:
                    rec.company_name = rec.partner_id.company_name or rec.partner_id.parent_id.name
                if not rec.user_id and rec.partner_id.user_ids:
                    rec.user_id = rec.partner_id.user_ids[:1]

    def _compute_stats(self):
        Acq = self.env["property.acquisition"]
        Lead = self.env["property.lead"]
        Comm = self.env["property.commission"]
        Asn = self.env["property.broker.assignment"]
        for broker in self:
            broker.acquisition_count = Acq.search_count([("broker_id", "=", broker.id)])
            broker.lead_count = Lead.search_count([("broker_id", "=", broker.id)])
            broker.commission_count = Comm.search_count([("broker_id", "=", broker.id)])
            broker.assignment_count = Asn.search_count([("broker_id", "=", broker.id)])
            paid = Comm.search([("broker_id", "=", broker.id), ("status", "=", "paid")])
            broker.total_commission_paid = sum(paid.mapped("commission_value"))

    @api.model_create_multi
    def create(self, vals_list):
        recs = super().create(vals_list)
        recs._sync_partner()
        recs._ensure_profile()
        return recs

    def write(self, vals):
        res = super().write(vals)
        tracked = {"name", "email", "phone", "mobile", "company_name", "partner_id", "user_id", "company_id"}
        if tracked.intersection(vals.keys()):
            self._sync_partner()
            self._ensure_profile()
        return res

    def action_view_acquisitions(self):
        self.ensure_one()
        return {"type": "ir.actions.act_window", "name": "Aquisições", "res_model": "property.acquisition", "view_mode": "list,form", "domain": [("broker_id", "=", self.id)], "context": {"default_broker_id": self.id}}

    def action_view_leads(self):
        self.ensure_one()
        return {"type": "ir.actions.act_window", "name": "Leads", "res_model": "property.lead", "view_mode": "list,form", "domain": [("broker_id", "=", self.id)], "context": {"default_broker_id": self.id}}

    def action_view_commissions(self):
        self.ensure_one()
        return {"type": "ir.actions.act_window", "name": "Comissões", "res_model": "property.commission", "view_mode": "list,form", "domain": [("broker_id", "=", self.id)], "context": {"default_broker_id": self.id}}

    def action_view_assignments(self):
        self.ensure_one()
        return {"type": "ir.actions.act_window", "name": "Mandatos", "res_model": "property.broker.assignment", "view_mode": "list,form", "domain": [("broker_id", "=", self.id)], "context": {"default_broker_id": self.id}}

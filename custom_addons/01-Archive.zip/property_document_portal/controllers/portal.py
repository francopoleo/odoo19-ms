from odoo import http
from odoo.addons.portal.controllers.portal import CustomerPortal, pager
from odoo.http import request


class PropertyDocumentPortal(CustomerPortal):
    def _prepare_home_portal_values(self, counters):
        """Add property documents count to portal home."""
        values = super()._prepare_home_portal_values(counters)

        if "property_document_count" in counters:
            document_count = self._get_portal_documents_count()
            values["property_document_count"] = document_count

        return values

    def _get_portal_documents_count(self):
        """Count documents visible to the current partner."""
        partner = request.env.user.partner_id
        domain = self._get_portal_document_domain(partner)
        return request.env["document.document"].search_count(domain)

    def _get_portal_document_domain(self, partner):
        """
        Build domain for documents visible to a specific partner.

        Returns documents that are:
        - website_published = True
        - access_level in ('portal', 'public')
        - AND at least one of:
          - access_level == 'public'
          - partner in shared_partner_ids
          - partner is tenant in active contract for asset_id
          - partner is broker with active mandate for asset_id
        """
        return [
            ("website_published", "=", True),
            ("access_level", "in", ("portal", "public")),
            "|",
            ("access_level", "=", "public"),
            "|",
            ("shared_partner_ids", "in", [partner.id]),
            "|",
            ("asset_id.contract_ids.partner_id", "=", partner.id),
            ("asset_id.contract_ids.status", "in", ("draft", "active", "expired", "renewing")),
        ]

    @http.route(["/my/documents", "/my/documents/page/<int:page>"], auth="user", website=True)
    def portal_my_documents(self, page=1, **kw):
        """List all documents visible to current user, grouped by property."""
        partner = request.env.user.partner_id
        domain = self._get_portal_document_domain(partner)

        # Count and fetch documents
        document_count = request.env["document.document"].search_count(domain)
        documents = request.env["document.document"].search(
            domain, order="asset_id, name", limit=20, offset=(page - 1) * 20
        )

        # Group by asset
        documents_by_asset = {}
        for doc in documents:
            if doc.asset_id not in documents_by_asset:
                documents_by_asset[doc.asset_id] = []
            documents_by_asset[doc.asset_id].append(doc)

        pager_result = pager(
            url="/my/documents",
            total=document_count,
            page=page,
            step=20,
        )

        values = {
            "documents_by_asset": documents_by_asset,
            "pager": pager_result,
            "page_name": "documents",
        }

        return request.render("property_document_portal.portal_my_documents", values)

    @http.route("/my/documents/<int:doc_id>", auth="user", website=True)
    def portal_document_page(self, doc_id, access_token=None, **kw):
        """Display document detail page."""
        document = request.env["document.document"].browse(doc_id)
        partner = request.env.user.partner_id

        # Verify document exists
        if not document.exists():
            return request.not_found()

        # Check access
        if not self._can_access_document(document, partner, access_token):
            return request.not_found()

        values = {
            "document": document,
            "page_name": "document",
        }

        return request.render("property_document_portal.portal_document_page", values)

    @http.route("/my/documents/<int:doc_id>/download", auth="user", website=True)
    def portal_document_download(self, doc_id, **kw):
        """Download document attachments as zip or single file."""
        document = request.env["document.document"].browse(doc_id)
        partner = request.env.user.partner_id

        # Verify document exists
        if not document.exists():
            return request.not_found()

        # Check access and download permission
        if not self._can_access_document(document, partner):
            return request.not_found()

        if not document.allow_download:
            return request.not_found()

        # If single attachment, download it directly
        if len(document.attachment_ids) == 1:
            import base64
            attachment = document.attachment_ids[0]

            # Get MIME type from attachment
            mime_type = attachment.mimetype or "application/octet-stream"

            # Decode base64 data
            file_data = base64.b64decode(attachment.datas) if attachment.datas else b""

            response = request.make_response(
                file_data,
                headers=[
                    ("Content-Type", mime_type),
                    (
                        "Content-Disposition",
                        f'attachment; filename="{attachment.name}"',
                    ),
                    ("Content-Length", str(len(file_data))),
                ],
            )
            return response

        # If multiple attachments, create zip
        if len(document.attachment_ids) > 1:
            import io
            import zipfile
            import base64
            from datetime import datetime

            zip_buffer = io.BytesIO()
            with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zip_file:
                for attachment in document.attachment_ids:
                    # Decode base64 data to binary
                    if attachment.datas:
                        file_data = base64.b64decode(attachment.datas)
                        zip_file.writestr(attachment.name, file_data)

            zip_buffer.seek(0)
            zip_filename = f"{document.name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"

            response = request.make_response(
                zip_buffer.read(),
                headers=[
                    ("Content-Type", "application/zip"),
                    (
                        "Content-Disposition",
                        f'attachment; filename="{zip_filename}"',
                    ),
                ],
            )
            return response

        # No attachments
        return request.not_found()

    @http.route("/my/properties/<int:asset_id>/documents", auth="user", website=True)
    def portal_property_documents(self, asset_id, **kw):
        """List documents for a specific property."""
        partner = request.env.user.partner_id
        asset = request.env["property.asset"].browse(asset_id)

        # Check if partner has access to this asset
        if not asset.exists():
            return request.not_found()

        # Verify partner has contract or broker assignment
        contracts = request.env["property.contract"].search(
            [
                ("asset_id", "=", asset_id),
                ("partner_id", "=", partner.id),
                ("status", "in", ("draft", "active", "expired", "renewing")),
            ]
        )

        if not contracts and hasattr(
            request.env["property.broker_assignment"], "_fields"
        ):
            broker_assignments = request.env["property.broker_assignment"].search(
                [
                    ("asset_id", "=", asset_id),
                    ("broker_id.partner_id", "=", partner.id),
                    ("status", "in", ("active", "pending")),
                ]
            )
            if not broker_assignments:
                return request.not_found()

        # Get documents for this asset
        domain = [
            ("website_published", "=", True),
            ("access_level", "in", ("portal", "public")),
            ("asset_id", "=", asset_id),
        ]

        documents = request.env["document.document"].search(
            domain, order="name"
        )

        values = {
            "asset": asset,
            "documents": documents,
            "page_name": "documents",
        }

        return request.render("property_document_portal.portal_property_documents", values)

    def _can_access_document(self, document, partner, access_token=None):
        """Check if partner can access a specific document."""
        # Public documents are always accessible
        if document.access_level == "public" and document.website_published:
            return True

        # Portal documents need auth
        if document.access_level not in ("portal", "public"):
            return False

        if not document.website_published:
            return False

        if not partner:
            return False

        # Check visibility rules
        if document.access_level == "public":
            return True

        # Direct sharing
        if partner in document.shared_partner_ids:
            return True

        # Via contract (tenant)
        if document.asset_id:
            contracts = request.env["property.contract"].search(
                [
                    ("asset_id", "=", document.asset_id.id),
                    ("partner_id", "=", partner.id),
                    ("status", "in", ("draft", "active", "expired", "renewing")),
                ]
            )
            if contracts:
                return True

            # Via broker mandate
            if hasattr(request.env["property.broker_assignment"], "_fields"):
                assignments = request.env["property.broker_assignment"].search(
                    [
                        ("asset_id", "=", document.asset_id.id),
                        ("broker_id.partner_id", "=", partner.id),
                        ("status", "in", ("active", "pending")),
                    ]
                )
                if assignments:
                    return True

        return False

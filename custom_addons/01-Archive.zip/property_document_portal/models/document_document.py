from odoo import api, fields, models


class DocumentDocument(models.Model):
    _inherit = "document.document"

    # Link to property asset
    asset_id = fields.Many2one(
        "property.asset",
        string="Property",
        ondelete="set null",
        index=True,
        help="Property asset associated with this document",
    )

    # Direct sharing with partners
    shared_partner_ids = fields.Many2many(
        "res.partner",
        "document_document_shared_partner_rel",
        "document_id",
        "partner_id",
        string="Shared with Partners",
        help="Partners with direct access to this document",
    )

    # Link to property contract
    property_contract_id = fields.Many2one(
        "property.contract",
        string="Property Contract",
        ondelete="set null",
        index=True,
        help="Property contract associated with this document",
    )

    @api.model
    def _is_visible_to_partner(self, partner, document):
        """
        Check if a document is visible to a specific partner.

        Visibility rules:
        1. Document must be website_published
        2. Access level must be 'portal' or 'public'
        3. Public documents: anyone can see
        4. Partner in shared_partner_ids: can see
        5. Partner is tenant in active contract for asset_id: can see
        6. Partner is broker with active mandate for asset_id: can see
        """
        if not document.website_published:
            return False

        if document.access_level not in ("portal", "public"):
            return False

        # Public documents are visible to everyone
        if document.access_level == "public":
            return True

        # Direct sharing
        if partner in document.shared_partner_ids:
            return True

        # Check via contract (tenant access)
        if document.asset_id:
            active_contracts = self.env["property.contract"].search(
                [
                    ("asset_id", "=", document.asset_id.id),
                    ("partner_id", "=", partner.id),
                    ("status", "in", ("draft", "active", "expired", "renewing")),
                ]
            )
            if active_contracts:
                return True

            # Check via broker mandate (broker access)
            if hasattr(self.env["property.broker_assignment"], "_fields"):
                broker_assignments = self.env["property.broker_assignment"].search(
                    [
                        ("asset_id", "=", document.asset_id.id),
                        ("broker_id.partner_id", "=", partner.id),
                        ("status", "in", ("active", "pending")),
                    ]
                )
                if broker_assignments:
                    return True

        return False

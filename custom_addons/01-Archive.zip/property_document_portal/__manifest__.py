{
    "name": "Property Document Portal",
    "version": "19.0.1.0.0",
    "category": "Properties",
    "summary": "Portal access to property documents for tenants, brokers, and stakeholders",
    "description": """
        Provides portal interface for viewing and downloading documents associated with properties.

        Features:
        - Document visibility by partner profile (tenant, broker, owner, public)
        - Filters documents by active contracts or broker assignments
        - Group documents by property for easy navigation
        - Download support respecting document permissions
        - Integration with property.contract and property.broker_assignment
    """,
    "author": "Franco Poleo / Manuela Silva",
    "website": "https://github.com/project-legions",
    "license": "LGPL-3",
    "depends": [
        "property_core",
        "document_core",
        "portal",
    ],
    "data": [
        "security/ir.model.access.csv",
        "views/portal_templates.xml",
    ],
    "installable": True,
    "auto_install": False,
    "application": False,
}
